# Python 3.13 build-reference inventory

- `config.c`
- `Setup`
- `Setup.bootstrap`
- `Setup.local`
- `Setup.stdlib`
- `install-sh`

- `recent_uploads/Makefile`
- `recent_uploads/config.c`
- `recent_uploads/makesetup`
- `recent_uploads/Setup.stdlib`
- `recent_uploads/README.md`
