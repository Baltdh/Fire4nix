# profile.d reference index

These files were added to keep the Fire4Nix backup aligned with the captured ROCKNIX shell hooks.

- `001-functions`
- `002-autostart`
- `010-wlr-randr`
- `045-xorg-server.conf`
- `050-sway.conf`
- `090-systemd.conf`
- `095-zerotier.conf`
- `098-box64.conf`
- `101-gpu-functions`
