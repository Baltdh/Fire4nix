# ROCKNIX reference additions

These files were added to the backup as reference material for the next Fire4Nix edit pass.

- `etc/systemd/journald.conf`
- `etc/systemd/logind.conf`
- `etc/systemd/oomd.conf`
- `etc/systemd/sleep.conf`
- `etc/systemd/resolved.conf`
- `etc/systemd/pstore.conf`
- `etc/systemd/timesyncd.conf`
- `etc/systemd/system.conf`
- `etc/systemd/user.conf`

- `etc/dbus-1/system.conf`
- `etc/dbus-1/session.conf`
- `etc/systemd/iocost.conf`
- `etc/udev/udev.conf`
- `etc/profile.d/00-at-spi`
- `etc/xdg/autostart/at-spi-dbus-bus.desktop`
- `etc/gtk-3.0/im-multipress.conf`
- `etc/foot.ini`

They are stored under `rocknix_reference/` so the project stays self-contained.

- `etc/dbus-1/system.d/nm-priv-helper.conf`
- `etc/dbus-1/system.d/nm-dispatcher.conf`
- `etc/dbus-1/system.d/avahi-dbus.conf`
- `etc/dbus-1/system.d/org.freedesktop.NetworkManager.conf`
- `etc/fonts/fonts.conf`
- `etc/ssl/certs/cacert.pem.system`

- `etc/profile.d/001-functions`
- `etc/profile.d/002-autostart`
- `etc/profile.d/010-wlr-randr`
- `etc/profile.d/045-xorg-server.conf`
- `etc/profile.d/050-sway.conf`
- `etc/profile.d/090-systemd.conf`
- `etc/profile.d/095-zerotier.conf`
- `etc/profile.d/098-box64.conf`
- `etc/profile.d/101-gpu-functions`

- `runtime-libs/README.md`
- `runtime-libs/aarch64/preloadable_libintl.so`
- `runtime-libs/aarch64/libXrender.so.1.3.0`
- `runtime-libs/aarch64/libxcb-render.so.0.0.0`
- `runtime-libs/aarch64/libxcb-present.so.0.0.0`
- `runtime-libs/aarch64/libxcb-glx.so.0.0.0`
- `runtime-libs/aarch64/libwbclient.so`
- `runtime-libs/aarch64/libwayland-egl.so.1.23.1`
- `runtime-libs/aarch64/libvlccore.so.9.0.1`
- `runtime-libs/aarch64/libstdc++.so.6.0.34`

- `runtime-libs/armhf/ld-linux-armhf.so.3`
- `runtime-libs/armhf/libavcodec.so.60.3.100`
- `runtime-libs/armhf/libOpenGL.so.0.0.0`
- `runtime-libs/armhf/libpcprofile.so`
- `runtime-libs/armhf/libwayland-client.so.0.23.1`
- `runtime-libs/armhf/libwayland-cursor.so.0.23.1`
- `runtime-libs/armhf/libwayland-egl.so.1.23.1`
- `runtime-libs/armhf/libwayland-server.so.0.23.1`
- `runtime-tools/armhf/gio-launch-desktop`
- `etc/NetworkManager/NetworkManager.conf`
- `etc/tmpfiles.d/systemd-tmp.conf`

- `devkit/armhf/pkgconfig/gio-2.0.pc`
- `devkit/armhf/pkgconfig/girepository-2.0.pc`
- `devkit/armhf/pkgconfig/cairo-xlib-xcb.pc`
- `devkit/armhf/pkgconfig/cairo-script.pc`


- `devkit/python313/recent_uploads/Makefile`
- `devkit/python313/recent_uploads/config.c`
- `devkit/python313/recent_uploads/makesetup`
- `devkit/python313/recent_uploads/Setup.stdlib`
- `devkit/python313/recent_uploads/README.md`

- `etc/tmpfiles.d/z_01_rocknix.conf`
- `etc/tmpfiles.d/README`
- `etc/tmpfiles.d/INVENTORY.md`
- `devkit/armhf/pkgconfig/xwayland.pc`
- `devkit/armhf/pkgconfig/glib-2.0.pc`
- `devkit/armhf/pkgconfig/gmodule-2.0.pc`
- `devkit/python313/Setup.stdlib`
- `devkit/python313/config.c`
- `devkit/python313/makesetup`
- `devkit/python313/Setup`
- `devkit/python313/Setup.bootstrap`
- `devkit/python313/Setup.local`
- `devkit/python313/install-sh`
- `runtime-libs/armhf/lib32-snapshot/README.md`
- `runtime-libs/armhf/lib32-snapshot/INVENTORY.md`