# Build / test on ROCKNIX

1. Copy the project folder to the ROCKNIX device.
2. Open `Fire4Nix.sh` directly from the file manager to launch the browser.
3. If you want to install the menu entry, run `Install-Fire4Nix.sh`.
4. Use `browser_manager.sh beta-check` to verify runtime detection if needed.
5. Use `Fire4Nix.sh --diagnose` for a single-step readiness report.


This backup keeps only the trimmed reference material that still helps the beta pass:
- ARMHF pkg-config snapshots
- tmpfiles.d reference configs
- the Fire4Nix launch/runtime code

Everything else that did not help the first test was removed to keep the package lean.


## WPE Platform beta path

The native launcher is built only when the ROCKNIX image exposes both WPE WebKit and the
Wayland WPE Platform pkg-config module. For WPE WebKit 2.52 this means building WPE WebKit
with `-DENABLE_WPE_PLATFORM=ON` and making these modules visible to `pkg-config`:

- `wpe-webkit-2.0`
- `wpe-platform-wayland-2.0` (or `wpe-platform-2.0`)

The launcher selects `wpe-display-wayland` when the active Wayland socket exists, otherwise
DRM when a DRM device is present, and headless only as a final fallback. This is the native
WPE Platform path; Cog remains the runtime fallback when the native launcher is unavailable.
