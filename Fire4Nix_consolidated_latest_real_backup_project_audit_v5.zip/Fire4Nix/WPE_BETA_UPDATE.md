# Fire4Nix WPE beta update

- Native launcher now selects the WPE Platform display at runtime.
- The GUI bridge now launches the WPE Platform runtime directly when a launcher is available, and keeps a local command/history journal for navigation state.
- Wayland is preferred when the active Wayland socket exists.
- DRM is selected only when no active Wayland socket is available and DRM devices exist.
- Headless is the final fallback.
- The build now requires `wpe-webkit-2.0` plus `wpe-platform-wayland-2.0` (or `wpe-platform-2.0`) for the native launcher.
- Cog remains the fallback when the native WPE Platform launcher is not available.
- Shell scripts pass `bash -n`; no exact duplicate files remain in the package.

- GUI home navigation now updates the browser state without double-launching the bridge.
- Launcher discovery also checks FIRE4NIX_BROWSER_BINARY for direct testing.
