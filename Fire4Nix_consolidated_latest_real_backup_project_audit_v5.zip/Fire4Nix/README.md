# Fire4Nix Browser

Fire4Nix is a lean browser shell for ROCKNIX on RK3326 handhelds.

Current focus:
- a direct launcher from the project folder
- the GUI-to-WPE bridge so navigation actions can launch the WPE runtime
- reduced clutter in the backup so only useful runtime and build references remain

## How to start
Copy the project folder to ROCKNIX and open `Fire4Nix.sh`.

Diagnostics: run `Fire4Nix.sh --diagnose` if you need a quick readiness report.

## What is still in the backup
- the Fire4Nix code and launch scripts
- the WPE/Cog integration path
- a trimmed ROCKNIX reference set for pkg-config and tmpfiles matching

See `BUILD_ON_ROCKNIX.md` for the minimal build/test flow.
