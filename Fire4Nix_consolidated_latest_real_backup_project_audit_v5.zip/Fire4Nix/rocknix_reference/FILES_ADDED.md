# ROCKNIX reference additions

Kept in this trimmed backup:

- `devkit/armhf/pkgconfig/` — ARMHF pkg-config snapshots used for build matching
- `devkit/armhf/include/` — small header snapshots needed by reference checks
- `etc/tmpfiles.d/` — tmpfiles config snapshots still useful for runtime matching

Removed from this pass:
- the large upstream WPE source trees
- duplicate launcher/theme assets
- unrelated ROCKNIX configuration snapshots that did not help the beta path
