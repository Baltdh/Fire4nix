# ROCKNIX reference bundle

This folder now keeps only the small reference set that still helps Fire4Nix:
- `devkit/armhf/pkgconfig/`
- `devkit/armhf/include/`
- `etc/tmpfiles.d/`

The larger upstream source snapshots and unused configuration trees were removed to keep the beta backup lean.
