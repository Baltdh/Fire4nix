# Lean beta notes

Trimmed from this backup:
- unpacked WPE source snapshots
- theme assets and duplicate EmulationStation variants
- diagnostic audit scripts and obsolete reference trees
- staged runtime snapshots that were not needed for the first ROCKNIX test

Kept for the beta path:
- the Fire4Nix launchers and WPE/Cog integration
- the installer
- the ARMHF pkg-config snapshots and tmpfiles reference set
- the minimal ROCKNIX launch/runtime diagnostics

Next step:
- validate the direct launch path on ROCKNIX and finish any last runtime-specific fix from the device.
