# Fire4Nix project audit — 2026-08-08

## Scope
Reviewed the current Fire4Nix beta tree, build system, GUI/WPE bridge, launch scripts,
and bundled ROCKNIX references. The review also checked the current upstream WPE
component compatibility information.

## Local verification

- Project files inspected: 204 archive entries / 221 extracted filesystem entries including directories.
- Exact duplicate-file groups: 0.
- Image files in the project tree: 0.
- Shell scripts checked with `bash -n`: all passed.
- Main Fire4Nix build: `make` passed in the available host environment.
- WPE Platform build: correctly stops with a dependency error when the host does not provide
  `wpe-webkit-2.0` plus `wpe-platform-wayland-2.0` or `wpe-platform-2.0`.
  This is an expected environment limitation, not a fabricated success.

## Changes in this audit

### Build system
The Makefile was simplified so the SDL build only asks pkg-config for `sdl2`.
Unused optional SDL_image, SDL_ttf, SDL_mixer and SDL_net dependencies were removed from
the default build flags. A real `BUILD_MODE=WPE_PLATFORM` path was added, and
`make wpe-platform` now builds the native launcher when the required WPE Platform
packages are actually installed.

### Native renderer safety
The framebuffer copy path in `src/main.cpp` now checks source/destination pointers
before `memcpy`. The normal host build no longer emits the previous null-destination
warning at that site.

## Upstream compatibility check

The project currently targets:
- WPE WebKit 2.52.x
- libwpe 1.16.x
- WPEBackend-fdo 1.16.x
- Cog 0.18.x

The upstream WPE compatibility table lists WPE WebKit 2.48.x–2.52.x as compatible
with libwpe 1.16.x, WPEBackend-fdo 1.16.x and Cog 0.18.x.

For WPE WebKit 2.52, upstream documents WPEPlatform as the preferred new integration
path. WPEPlatform can provide built-in Wayland, DRM/KMS and headless implementations;
when using WPEPlatform explicitly, libwpe and an external WPE backend are no longer
required for those common targets. WPEPlatform is not enabled by default in 2.52,
so the ROCKNIX build must enable it.

## Remaining work before hardware validation

1. Build WPE WebKit with WPEPlatform enabled in the actual ROCKNIX/toolchain environment.
2. Build the native `fire4nix-wpe-platform` launcher against the resulting pkg-config files.
3. Run the GUI/WPE bridge on the R36H and verify that the WPE view actually presents through
   the selected Wayland display.
4. Verify R36H input delivery to the WPE view.
5. Only after that, remove any remaining compatibility/fallback code proven unnecessary
   by the hardware test.

## Important architectural note

Cog remains useful as a fallback during validation, but it should not become a second
primary implementation. The current direction should remain GUI -> WPEPlatform, with
Cog only as a fallback when WPEPlatform is unavailable.

## Not removed in this audit

The large legacy Firefox framebuffer wrapper and its references were deliberately left
in place because the current source tree still references them. Removing them safely
requires first removing those references and validating that no legacy launch path is
still expected by the installer/runtime. That should be a separate cleanup after the
WPE path is proven on hardware.
