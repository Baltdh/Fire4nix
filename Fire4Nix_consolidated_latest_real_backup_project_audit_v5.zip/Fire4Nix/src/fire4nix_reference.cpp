#include "fire4nix_reference.hpp"

#include <cstdlib>
#include <filesystem>
#include <sstream>
#include <string>
#include <system_error>
#include <vector>

namespace fire4nix {
namespace {

std::filesystem::path normalizeCandidate(const std::filesystem::path& candidate)
{
    std::error_code ec;
    const auto canonical = std::filesystem::weakly_canonical(candidate, ec);
    if (!ec && !canonical.empty()) {
        return canonical;
    }
    return candidate.lexically_normal();
}

std::vector<std::filesystem::path> candidateRoots()
{
    std::vector<std::filesystem::path> roots;

    if (const char* env = std::getenv("FIRE4NIX_REFERENCE_ROOT"); env != nullptr && *env != '\0') {
        roots.emplace_back(env);
    }
    if (const char* cfg = std::getenv("FIRE4NIX_CONFIG_DIR"); cfg != nullptr && *cfg != '\0') {
        roots.emplace_back(std::filesystem::path(cfg) / "reference");
    }

    roots.emplace_back("rocknix_reference");
    roots.emplace_back(std::filesystem::current_path() / "rocknix_reference");
    return roots;
}

std::filesystem::path chooseReferenceRoot()
{
    for (const auto& root : candidateRoots()) {
        std::error_code ec;
        if (std::filesystem::exists(root, ec) && std::filesystem::is_directory(root, ec)) {
            return normalizeCandidate(root);
        }
    }
    return {};
}

std::size_t countRegularFiles(const std::filesystem::path& root)
{
    std::error_code ec;
    if (!std::filesystem::exists(root, ec) || !std::filesystem::is_directory(root, ec)) {
        return 0;
    }

    std::size_t count = 0;
    for (std::filesystem::recursive_directory_iterator it(root, ec), end; !ec && it != end; it.increment(ec)) {
        if (ec) {
            break;
        }
        std::error_code entryEc;
        if (it->is_regular_file(entryEc) && !entryEc) {
            ++count;
        }
    }
    return count;
}


std::string groupSummary(const std::filesystem::path& root)
{
    std::vector<std::string> groups;

    const auto headerCount = countRegularFiles(root / "devkit/armhf/include");
    const auto tmpfilesCount = countRegularFiles(root / "etc/tmpfiles.d");
    const auto pkgconfigCount = countRegularFiles(root / "devkit/armhf/pkgconfig");

    if (headerCount > 0) groups.emplace_back("headers:" + std::to_string(headerCount));
    if (tmpfilesCount > 0) groups.emplace_back("tmpfiles:" + std::to_string(tmpfilesCount));
    if (pkgconfigCount > 0) groups.emplace_back("pkgconfig-armhf:" + std::to_string(pkgconfigCount));

    std::ostringstream out;
    for (std::size_t idx = 0; idx < groups.size(); ++idx) {
        if (idx != 0) {
            out << " • ";
        }
        out << groups[idx];
    }
    return out.str();
}


} // namespace

ReferencePackReport detectReferencePack()
{
    ReferencePackReport report;
    const auto root = chooseReferenceRoot();
    if (root.empty()) {
        report.summary = "reference pack unavailable";
        return report;
    }

    report.available = true;
    report.root = root.string();
    report.fileCount = countRegularFiles(root);

    static const std::vector<std::string> anchors = {
        "devkit/armhf/include/glibconfig.h",
        "devkit/armhf/include/dbus-arch-deps.h",
        "devkit/armhf/pkgconfig/gio-2.0.pc",
        "devkit/armhf/pkgconfig/girepository-2.0.pc",
        "devkit/armhf/pkgconfig/cairo-xlib-xcb.pc",
        "devkit/armhf/pkgconfig/glib-2.0.pc",
        "devkit/armhf/pkgconfig/gmodule-2.0.pc",
        "etc/tmpfiles.d/systemd-tmp.conf",
        "etc/tmpfiles.d/INVENTORY.md",
    };


    report.anchorCount = anchors.size();
    for (const auto& rel : anchors) {
        std::error_code ec;
        if (std::filesystem::exists(root / rel, ec) && std::filesystem::is_regular_file(root / rel, ec)) {
            ++report.presentCount;
        }
    }

    std::ostringstream summary;
    summary << "root=" << report.root << " • anchors " << report.presentCount << "/" << report.anchorCount;
    const auto groups = groupSummary(root);
    if (!groups.empty()) {
        summary << " • " << groups;
    }
    if (report.anchorCount > 0) {
        const auto coverage = static_cast<unsigned int>((report.presentCount * 100) / report.anchorCount);
        summary << " • coverage " << coverage << "%";
    }
    summary << " • files " << report.fileCount;
    report.summary = summary.str();
    return report;
}

std::string referencePackSummary()
{
    return detectReferencePack().summary;
}

std::string referencePackManifestPath()
{
    if (const char* env = std::getenv("FIRE4NIX_REFERENCE_MANIFEST"); env != nullptr && *env != '\0') {
        return std::string(env);
    }

    const auto report = detectReferencePack();
    if (!report.available || report.root.empty()) {
        return {};
    }

    const std::filesystem::path root(report.root);
    const auto candidate = (root.parent_path() / "reference-manifest.txt").lexically_normal();
    std::error_code ec;
    if (std::filesystem::exists(candidate, ec) && std::filesystem::is_regular_file(candidate, ec)) {
        return candidate.string();
    }

    if (const char* cfg = std::getenv("FIRE4NIX_CONFIG_DIR"); cfg != nullptr && *cfg != '\0') {
        const auto staged = (std::filesystem::path(cfg) / "reference-manifest.txt").lexically_normal();
        if (std::filesystem::exists(staged, ec) && std::filesystem::is_regular_file(staged, ec)) {
            return staged.string();
        }
        return staged.string();
    }

    return candidate.string();
}

} // namespace fire4nix
