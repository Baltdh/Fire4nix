#include "browser_bridge.hpp"

#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <string>
#include <vector>

#ifndef _WIN32
#  include <signal.h>
#  include <sys/types.h>
#  include <unistd.h>
#endif

namespace fire4nix::gui {
namespace {

std::string trimCopy(const std::string& text)
{
    const auto begin = text.find_first_not_of(" \t\r\n");
    if (begin == std::string::npos) {
        return {};
    }
    const auto end = text.find_last_not_of(" \t\r\n");
    return text.substr(begin, end - begin + 1);
}

std::string envOr(const char* name, const std::string& fallback)
{
    const char* value = std::getenv(name);
    if (value == nullptr || *value == '\0') {
        return fallback;
    }
    return trimCopy(value);
}

std::string nowStamp()
{
    using clock = std::chrono::system_clock;
    const auto now = clock::now();
    const std::time_t tt = clock::to_time_t(now);
    std::tm tm{};
#if defined(_WIN32)
    localtime_s(&tm, &tt);
#else
    localtime_r(&tt, &tm);
#endif
    char buf[32]{};
    std::strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", &tm);
    return std::string(buf);
}

std::filesystem::path resolveBridgeJournalPath()
{
    if (const char* explicitPath = std::getenv("FIRE4NIX_BRIDGE_JOURNAL"); explicitPath != nullptr && *explicitPath != '\0') {
        return std::filesystem::path(trimCopy(explicitPath));
    }

    if (const char* runtimeDir = std::getenv("FIRE4NIX_RUNTIME_DIR"); runtimeDir != nullptr && *runtimeDir != '\0') {
        return std::filesystem::path(trimCopy(runtimeDir)) / "bridge-journal.log";
    }

    if (const char* configDir = std::getenv("FIRE4NIX_CONFIG_DIR"); configDir != nullptr && *configDir != '\0') {
        return std::filesystem::path(trimCopy(configDir)) / "runtime" / "bridge-journal.log";
    }

    return std::filesystem::path(".fire4nix") / "runtime" / "bridge-journal.log";
}

void appendBridgeJournalLine(const std::string& line)
{
    const auto path = resolveBridgeJournalPath();
    std::error_code ec;
    if (const auto parent = path.parent_path(); !parent.empty()) {
        std::filesystem::create_directories(parent, ec);
    }
    std::ofstream out(path, std::ios::app);
    if (!out.is_open()) {
        return;
    }
    out << line << '\n';
}

std::filesystem::path resolveExecutablePath()
{
#if defined(_WIN32)
    return std::filesystem::current_path();
#elif defined(__linux__)
    char buffer[4096]{};
    const ssize_t len = ::readlink("/proc/self/exe", buffer, sizeof(buffer) - 1);
    if (len > 0) {
        buffer[len] = '\0';
        return std::filesystem::path(buffer);
    }
    return std::filesystem::current_path();
#else
    return std::filesystem::current_path();
#endif
}

std::filesystem::path resolveAppDir()
{
    auto exe = resolveExecutablePath();
    auto dir = exe.has_parent_path() ? exe.parent_path() : std::filesystem::current_path();
    if (dir.filename() == "bin") {
        dir = dir.parent_path();
    }
    if (dir.empty()) {
        dir = std::filesystem::current_path();
    }
    return dir;
}

bool isExecutable(const std::filesystem::path& path)
{
#if defined(_WIN32)
    return std::filesystem::exists(path);
#else
    return !path.empty() && std::filesystem::exists(path) && ::access(path.c_str(), X_OK) == 0;
#endif
}

std::filesystem::path resolveLauncherPath()
{
    const auto appDir = resolveAppDir();
    const std::vector<std::filesystem::path> candidates = {
        std::filesystem::path(envOr("FIRE4NIX_BROWSER_BINARY", std::string())),
        std::filesystem::path(envOr("FIRE4NIX_WPE_PLATFORM_BINARY", std::string())),
        std::filesystem::path(envOr("FIRE4NIX_HOME", appDir.string())) / "bin/fire4nix-wpe-platform",
        std::filesystem::path(envOr("FIRE4NIX_HOME", appDir.string())) / "bin/wpe-platform-launcher",
        std::filesystem::path(envOr("FIRE4NIX_HOME", appDir.string())) / "scripts/wpe_platform_launch.sh",
        appDir / "bin/fire4nix-wpe-platform",
        appDir / "bin/wpe-platform-launcher",
        appDir / "scripts/wpe_platform_launch.sh",
        appDir / "build/fire4nix-wpe-platform",
        appDir / "build/wpe-platform-launcher",
    };

    for (const auto& candidate : candidates) {
        if (isExecutable(candidate)) {
            return candidate;
        }
    }

    return {};
}

bool launchDetached(const std::filesystem::path& executable, const std::vector<std::string>& args)
{
    if (executable.empty()) {
        return false;
    }

#ifndef _WIN32
    pid_t pid = fork();
    if (pid < 0) {
        return false;
    }

    if (pid == 0) {
        ::setsid();

        std::vector<std::string> argvStorage;
        argvStorage.reserve(args.size() + 2);

        if (executable.extension() == ".sh") {
            argvStorage.emplace_back("bash");
            argvStorage.emplace_back(executable.string());
        } else {
            argvStorage.emplace_back(executable.string());
        }

        for (const auto& arg : args) {
            argvStorage.emplace_back(arg);
        }

        std::vector<char*> argv;
        argv.reserve(argvStorage.size() + 1);
        for (auto& item : argvStorage) {
            argv.push_back(item.data());
        }
        argv.push_back(nullptr);

        if (executable.extension() == ".sh") {
            execv("/bin/bash", argv.data());
        } else {
            execv(executable.c_str(), argv.data());
        }
        _exit(127);
    }

    return true;
#else
    (void)executable;
    (void)args;
    return false;
#endif
}

std::string defaultStartUrl()
{
    return envOr("FIRE4NIX_START_PAGE",
                 envOr("FIRE4NIX_HOME_URL",
                        envOr("FIRE4NIX_DEFAULT_HOME_URL", "about:home")));
}

class RuntimeBrowserBridge final : public BrowserBridge {
public:
    RuntimeBrowserBridge()
        : launcherPath_(resolveLauncherPath())
    {
    }

    bool loadUrl(const std::string& url) override
    {
        const auto target = trimCopy(url);
        record("load " + target);
        if (target.empty()) {
            return false;
        }

        pushHistory(target);
        currentUrl_ = target;
        return launchCurrent(target);
    }

    bool reload() override
    {
        const auto target = currentUrl_.empty()
            ? defaultStartUrl()
            : currentUrl_;
        record("reload");
        if (currentUrl_.empty()) {
            currentUrl_ = target;
            pushHistory(target);
        }
        return launchCurrent(target);
    }

    bool goHome() override
    {
        const auto target = defaultStartUrl();
        record("home");
        pushHistory(target);
        currentUrl_ = target;
        return launchCurrent(target);
    }

    bool goBack() override
    {
        record("back");
        if (history_.empty() || historyIndex_ == 0) {
            return false;
        }

        --historyIndex_;
        currentUrl_ = history_[historyIndex_];
        return launchCurrent(currentUrl_);
    }

    bool goForward() override
    {
        record("forward");
        if (history_.empty() || historyIndex_ + 1 >= history_.size()) {
            return false;
        }

        ++historyIndex_;
        currentUrl_ = history_[historyIndex_];
        return launchCurrent(currentUrl_);
    }

    bool openTab(const std::string& title) override
    {
        record("open-tab " + trimCopy(title));
        return true;
    }

    bool closeTab() override
    {
        record("close-tab");
        return true;
    }

    bool toggleFullscreen() override
    {
        record("fullscreen");
        return true;
    }

    std::string describe() const override
    {
        return std::string("wpe bridge ") + (launcherPath_.empty() ? "journal-only" : std::string("connected via ") + launcherPath_.string()) +
               " • " + stateSummary();
    }

    std::string stageLabel() const override
    {
        return envOr("FIRE4NIX_PROGRESS_STAGE_NAME", envOr("FIRE4NIX_PROGRESS_STAGE", "wpe-platform-beta"));
    }

    std::size_t commandCount() const override
    {
        std::lock_guard<std::mutex> lock(mutex_);
        return commands_.size();
    }

    std::string journalSummary() const override
    {
        std::lock_guard<std::mutex> lock(mutex_);
        if (commands_.empty()) {
            return "journal idle";
        }
        return std::to_string(commands_.size()) + " commands";
    }

    std::string lastCommand() const override
    {
        std::lock_guard<std::mutex> lock(mutex_);
        return lastCommand_.empty() ? std::string("none") : lastCommand_;
    }

    std::string stateSummary() const override
    {
        return journalSummary() + " • last " + lastCommand() + " • url " + (currentUrl_.empty() ? std::string("none") : currentUrl_) + " • path " + launcherLabel();
    }

    std::string launcherLabel() const
    {
        return launcherPath_.empty() ? std::string("shell-journal") : launcherPath_.string();
    }

private:
    void pushHistory(const std::string& url)
    {
        if (url.empty()) {
            return;
        }

        if (!history_.empty() && historyIndex_ < history_.size() && history_[historyIndex_] == url) {
            currentUrl_ = url;
            return;
        }

        if (!history_.empty() && historyIndex_ + 1 < history_.size()) {
            history_.erase(history_.begin() + static_cast<std::ptrdiff_t>(historyIndex_ + 1), history_.end());
        }

        history_.push_back(url);
        historyIndex_ = history_.empty() ? 0 : history_.size() - 1;
    }

    bool launchCurrent(const std::string& target)
    {
        if (launcherPath_.empty()) {
            return false;
        }

        const bool launched = launchDetached(launcherPath_, {target});
        if (launched) {
            appendBridgeJournalLine(nowStamp() + " | stage=" + stageLabel() + " | launch=" + target + " | launcher=" + launcherLabel());
        }
        return launched;
    }

    void record(const std::string& command)
    {
        std::lock_guard<std::mutex> lock(mutex_);
        commands_.push_back(command);
        lastCommand_ = command;
        if (commands_.size() > 32) {
            commands_.erase(commands_.begin(), commands_.begin() + static_cast<std::ptrdiff_t>(commands_.size() - 32));
        }

        appendBridgeJournalLine(nowStamp() + " | stage=" + stageLabel() + " | command=" + command);
    }

    mutable std::mutex mutex_;
    std::vector<std::string> commands_;
    std::string lastCommand_;
    std::vector<std::string> history_;
    std::size_t historyIndex_{0};
    std::string currentUrl_;
    std::filesystem::path launcherPath_;
};

RuntimeBrowserBridge g_runtimeBridge;

} // namespace

BrowserBridge& defaultBrowserBridge()
{
    return g_runtimeBridge;
}

std::string bridgeJournalSummary()
{
    return g_runtimeBridge.journalSummary();
}

std::size_t bridgeJournalCommandCount()
{
    return g_runtimeBridge.commandCount();
}

std::string bridgeJournalLastCommand()
{
    return g_runtimeBridge.lastCommand();
}

std::string bridgeJournalPath()
{
    return resolveBridgeJournalPath().string();
}

std::string bridgeJournalStateSummary()
{
    return g_runtimeBridge.stateSummary();
}

} // namespace fire4nix::gui
