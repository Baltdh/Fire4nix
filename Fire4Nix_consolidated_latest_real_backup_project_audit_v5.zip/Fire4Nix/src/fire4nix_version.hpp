#pragma once
#define FIRE4NIX_VERSION "0.84-beta-wpe-platform-bridge2"
#define FIRE4NIX_PLATFORM "ROCKNIX"
