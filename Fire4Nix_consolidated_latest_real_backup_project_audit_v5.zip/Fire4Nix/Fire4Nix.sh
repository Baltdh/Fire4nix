#!/bin/sh
set -eu

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

show_usage() {
    cat <<'EOF'
Fire4Nix launcher

Usage:
  Fire4Nix.sh
  Fire4Nix.sh <url>
  Fire4Nix.sh --status
  Fire4Nix.sh --diagnose
  Fire4Nix.sh --beta-check
  Fire4Nix.sh --engine-status
  Fire4Nix.sh --engine-detect
  Fire4Nix.sh --help
EOF
}

exec_browser() {
    if [ -x "$SCRIPT_DIR/scripts/run_browser.sh" ]; then
        exec "$SCRIPT_DIR/scripts/run_browser.sh" "$@"
    fi
    if [ -x "$SCRIPT_DIR/bin/browser.arm64" ]; then
        exec "$SCRIPT_DIR/bin/browser.arm64" "$@"
    fi
    if [ -x "$SCRIPT_DIR/scripts/wpe_platform_launch.sh" ]; then
        exec "$SCRIPT_DIR/scripts/wpe_platform_launch.sh" "$@"
    fi
    echo "Fire4Nix launcher could not find a runnable browser entry point." >&2
    exit 1
}

case "${1:-}" in
    -h|--help|help)
        show_usage
        exit 0
        ;;
    --status)
        exec "$SCRIPT_DIR/scripts/browser_manager.sh" status
        ;;
    --diagnose|--beta-check)
        exec "$SCRIPT_DIR/scripts/browser_manager.sh" beta-check
        ;;
    --engine-status)
        exec "$SCRIPT_DIR/scripts/engine_manager.sh" status
        ;;
    --engine-detect)
        exec "$SCRIPT_DIR/scripts/engine_manager.sh" detect
        ;;
    --launch)
        shift
        exec_browser "$@"
        ;;
    *)
        exec_browser "$@"
        ;;
esac
